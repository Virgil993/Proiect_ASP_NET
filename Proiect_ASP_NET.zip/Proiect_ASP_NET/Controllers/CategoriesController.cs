﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Proiect.DAL;
using Proiect.DAL.Entities;
using Proiect.DAL.Entities.DTOs;
using Proiect.DAL.Repositories.CategoryRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Proiect_ASP_NET.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoriesController : ControllerBase
    {
        private readonly ICategoryRepository _repository;

        public CategoriesController(ICategoryRepository repository)
        {
            _repository = repository;
        }

        [Authorize(AuthenticationSchemes = "Bearer")]
        [Authorize(Roles = "User,Admin")]
        [HttpGet]
        public async Task<IActionResult> GetAllCateogries()
        {
            var categories = _repository.GetAll();

            var categoriesToReturn = new List<CategoryDTO>();

            foreach (var category in categories)
            {
                categoriesToReturn.Add(new CategoryDTO(category));
            }

            return Ok(categoriesToReturn);
        }

        [Authorize(AuthenticationSchemes = "Bearer")]
        [Authorize(Roles = "User,Admin")]
        [HttpGet("{Id}")]
        public async Task<IActionResult> GetCategoryById(int Id)
        {
            var category = await _repository.GetByIdAsync(Id);

            if(category==null)
            {
                return NotFound("No category exists with this ID!");
            }

            return Ok(new CategoryDTO(category));
        }

        [Authorize(AuthenticationSchemes = "Bearer")]
        [Authorize(Roles = "Admin")]
        [HttpDelete("{Id}")]
        public async Task<IActionResult> DeleteCategory([FromRoute] int Id)
        {
            var category = await _repository.GetByIdAsync(Id);

            if (category == null)
            {
                return NotFound("No category exists with this ID!");
            }

            _repository.Delete(category);

            await _repository.SaveAsync();

            return NoContent();
        }
        [Authorize(AuthenticationSchemes = "Bearer")]
        [Authorize(Roles = "Admin")]
        [HttpPost]
        public async Task<IActionResult> CreateCategory(CreateCategoryDTO dto)
        {
            Category newcat = new Category();

            newcat.Name = dto.Name;

            _repository.Create(newcat);

            await _repository.SaveAsync();


            return Ok(new CategoryDTO(newcat));
        }

        [Authorize(AuthenticationSchemes = "Bearer")]
        [Authorize(Roles = "Admin")]
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateCategory(int id, CreateCategoryDTO dto)
        {

            var newcat = await _repository.GetByIdAsync(id);
            if (newcat == null)
            {
                return NotFound("Category dosen't exist with this ID!");
            }

            newcat.Name = dto.Name;

            _repository.Update(newcat);

            await _repository.SaveAsync();

            return Ok(new CategoryDTO(newcat));
        }
    }
}
