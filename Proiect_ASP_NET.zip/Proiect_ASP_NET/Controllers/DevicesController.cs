﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Proiect.DAL;
using Proiect.DAL.Entities;
using Proiect.DAL.Entities.DTOs;
using Proiect.DAL.Repositories.DeviceRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Proiect_ASP_NET.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DevicesController : ControllerBase
    {
        private readonly IDeviceRepository _repository;

        public DevicesController(IDeviceRepository repository)
        {
            _repository = repository;
        }

        [Authorize(AuthenticationSchemes = "Bearer")]
        [Authorize(Roles = "User,Admin")]
        [HttpGet]
        public async Task<IActionResult> GetAllDevices()
        {
            var devices =  _repository.GetAll();

            var devicesToReturn = new List<DeviceDTO>();

            foreach (var device in devices)
            {
                devicesToReturn.Add(new DeviceDTO(device));
            }

            return Ok(devicesToReturn);
        }


        [Authorize(AuthenticationSchemes = "Bearer")]
        [Authorize(Roles = "User,Admin")]
        [HttpGet("{id}")]
        public async Task<IActionResult> GetDeviceById(int id)
        {
            var device = await _repository.GetByIdAsync(id);

            return Ok(new DeviceDTO(device));
        }

        [Authorize(AuthenticationSchemes = "Bearer")]
        [Authorize(Roles = "Admin")]
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteDevice(int id)
        {
            var device = await _repository.GetByIdAsync(id);

            if (device == null)
            {
                return NotFound("Device does not exist!");
            }

            _repository.Delete(device);

            await _repository.SaveAsync();

            return NoContent();
        }

        [Authorize(AuthenticationSchemes = "Bearer")]
        [Authorize(Roles = "Admin")]
        [HttpPost]
        public async Task<IActionResult> CreateDevice(CreateDeviceDTO dto)
        {
            Device newDevice = new Device();

            newDevice.Name = dto.Name;

            _repository.Create(newDevice);

            await _repository.SaveAsync();


            return Ok(new DeviceDTO(newDevice));
        }


        [Authorize(AuthenticationSchemes = "Bearer")]
        [Authorize(Roles = "Admin")]
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateDevice(int id, CreateDeviceDTO dto)
        {

            var newDevice = await _repository.GetByIdAsync(id);
            if (newDevice == null)
            {
                return NotFound("Device dosen't exist with this ID!");
            }

            newDevice.Name = dto.Name;

            _repository.Update(newDevice);

            await _repository.SaveAsync();

            return Ok(new DeviceDTO(newDevice));
        }


    }
}
