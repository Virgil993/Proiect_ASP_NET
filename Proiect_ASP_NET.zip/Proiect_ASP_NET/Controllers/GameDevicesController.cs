﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Proiect.DAL;
using Proiect.DAL.Entities;
using Proiect.DAL.Entities.DTOs;
using Proiect.DAL.Repositories.GameDeviceRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Proiect_ASP_NET.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GameDevicesController : ControllerBase
    {
        private readonly IGameDeviceRepository _repository;
        
        public GameDevicesController(IGameDeviceRepository repository)
        {
            _repository = repository;
        }

        [Authorize(AuthenticationSchemes = "Bearer")]
        [Authorize(Roles = "Admin")]
        [HttpGet]
        public async Task<IActionResult> GetAllGameDevices()
        {
            var gameDevices = await _repository.GetAllGameDevicesWithGameAndDevice();

            var gameDevicesToReturn = new List<GameDeviceDTO>();

            foreach (var gameDevice in gameDevices)
            {
                gameDevicesToReturn.Add(new GameDeviceDTO(gameDevice));
            }

            return Ok(gameDevicesToReturn);
        }

        [Authorize(AuthenticationSchemes = "Bearer")]
        [Authorize(Roles = "Admin")]
        [HttpGet("{id}")]
        public async Task<IActionResult> GetGameDeviceById(int id)
        {
            var gamedevice = await _repository.GetByIdWithGameAndDevice(id);

            return Ok(new GameDeviceDTO(gamedevice));
        }

        [Authorize(AuthenticationSchemes = "Bearer")]
        [Authorize(Roles = "Admin")]
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteGameDevice(int id)
        {
            var gameDevice = await _repository.GetByIdWithGameAndDevice(id);

            if (gameDevice == null)
            {
                return NotFound("GameDevice does not exist!");
            }

            _repository.Delete(gameDevice);

            await _repository.SaveAsync();

            return NoContent();
        }

        [Authorize(AuthenticationSchemes = "Bearer")]
        [Authorize(Roles = "Admin")]
        [HttpPost]
        public async Task<IActionResult> CreateGameDevice(CreateGameDeviceDTO dto)
        {
            GameDevice newGameDevice = new GameDevice();

            newGameDevice.GameId = dto.GameId;
            newGameDevice.DeviceId = dto.DeviceId;
            newGameDevice.Device = dto.Device;
            newGameDevice.Game = dto.Game;

            _repository.Create(newGameDevice);

            await _repository.SaveAsync();


            return Ok(new GameDeviceDTO(newGameDevice));
        }

        [Authorize(AuthenticationSchemes = "Bearer")]
        [Authorize(Roles = "Admin")]
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateGameDevice(int id, CreateGameDeviceDTO dto)
        {

            var newGameDevice = await _repository.GetByIdWithGameAndDevice(id);
            if (newGameDevice == null)
            {
                return NotFound("Device dosen't exist with this ID!");
            }

            newGameDevice.GameId = dto.GameId;
            newGameDevice.DeviceId = dto.DeviceId;
            newGameDevice.Device = dto.Device;
            newGameDevice.Game = dto.Game;

            _repository.Update(newGameDevice);

            await _repository.SaveAsync();

            return Ok(new GameDeviceDTO(newGameDevice));
        }


    }
}
