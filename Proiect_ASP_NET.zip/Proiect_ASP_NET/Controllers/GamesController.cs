﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Proiect.DAL;
using Proiect.DAL.Entities;
using Proiect.DAL.Entities.DTOs;
using Proiect.DAL.Repositories.GameRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Proiect_ASP_NET.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GamesController : ControllerBase
    {
        private readonly IGameRepository _repository;
        private readonly AppDbContext _context;

        public GamesController(IGameRepository repository,AppDbContext context)
        {
            _repository = repository;
            _context = context;
        }

        [AllowAnonymous]
        [HttpGet("get_join")]
        public async Task<IActionResult> GetGamesWithDeveloperName()
        {
            var developers = _context.Developers;
            var gamesDeveloper = _context.Games.Join(developers, b => b.Id, a => a.GameId, (b, a) => new {

                GameId = a.GameId,
                GameName = b.Name,
                DeveloperName = a.FirstName + " " + a.LastName

            }).ToList();

            return Ok(gamesDeveloper);
        }

        [AllowAnonymous]
        [HttpGet("get_group_by")]
        public async Task<IActionResult> GetNumberOfGamesForEachDevice()
        {
            var numberGames = _context.GameDevices.ToList().GroupBy(x => x.DeviceId).Select(x => new
            {
                DeviceKey = x.Key,
                Count = x.Count()
            });

            return Ok(numberGames);
        }

        [Authorize(AuthenticationSchemes = "Bearer")]
        [Authorize(Roles = "User")]
        [HttpGet]
        public async Task<IActionResult> GetAllGames()
        {
            var games = await _repository.GetAllGamesWithCategoryAndDeveloper();

            var gamesToReturn = new List<GameDTO>();

            foreach (var game in games)
            {
                gamesToReturn.Add(new GameDTO(game));
            }

            return Ok(gamesToReturn);
        }

        [Authorize(AuthenticationSchemes = "Bearer")]
        [Authorize(Roles = "User")]
        [HttpGet("{id}")]
        public async Task<IActionResult> GetGameById(int Id)
        {
            var game = await _repository.GetByIdWithCategoryAndDeveloper(Id);

            return Ok(new GameDTO(game));
        }

        [Authorize(AuthenticationSchemes = "Bearer")]
        [Authorize(Roles = "Admin")]
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteGame(int Id)
        {
            var game = await _repository.GetByIdAsync(Id);
            if (game == null)
            {
                return NotFound("Game dosen't exist!");

            }

            _repository.Delete(game);

            await _repository.SaveAsync();

            return NoContent();
        }
        [Authorize(AuthenticationSchemes = "Bearer")]
        [Authorize(Roles = "Admin")]
        [HttpPost]
        public async Task<IActionResult> CreateGame(CreateGameDTO dto)
        {
            Game newgame = new Game();

            newgame.Name = dto.Name;
            newgame.ReleaseDate = dto.ReleaseDate;
            newgame.CategoryId = dto.CategoryId;
            newgame.Category = dto.Category;
            newgame.Developer = dto.Developer;

            _repository.Create(newgame);

            await _repository.SaveAsync();

            return Ok(new GameDTO(newgame));
        }
        [Authorize(AuthenticationSchemes = "Bearer")]
        [Authorize(Roles = "Admin")]
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateGame(int id,CreateGameDTO dto)
        {

            var newgame = await _repository.GetByIdWithCategoryAndDeveloper(id);
            if(newgame==null)
            {
                return NotFound("game dosen't exist with this ID!");
            }

            newgame.Name = dto.Name;
            newgame.ReleaseDate = dto.ReleaseDate;
            newgame.CategoryId = dto.CategoryId;
            newgame.Category = dto.Category;
            newgame.Developer = dto.Developer;

            _repository.Update(newgame);

            await _repository.SaveAsync();

            return Ok(new GameDTO(newgame));
        }
    }
}
