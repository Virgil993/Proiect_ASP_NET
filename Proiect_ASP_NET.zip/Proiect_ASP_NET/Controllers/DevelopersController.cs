﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Proiect.DAL;
using Proiect.DAL.Entities;
using Proiect.DAL.Entities.DTOs;
using Proiect.DAL.Repositories.DeveloperRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Proiect_ASP_NET.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DevelopersController : ControllerBase
    {
        private readonly IDeveloperRepository _repository;

        public DevelopersController(IDeveloperRepository repository)
        {
            _repository = repository;
        }

        [Authorize(AuthenticationSchemes = "Bearer")]
        [Authorize(Roles = "User,Admin")]
        [HttpGet]
        public async Task<IActionResult> GetAllDevelopers()
        {
            var devs = await _repository.GetAllDevelopersWithGame();

            var devsToReturn = new List<DeveloperDTO>();

            foreach (var dev in devs)
            {
                devsToReturn.Add(new DeveloperDTO(dev));
            }

            return Ok(devsToReturn);
        }

        [Authorize(AuthenticationSchemes = "Bearer")]
        [Authorize(Roles = "User,Admin")]
        [HttpGet("{Id}")]
        public async Task<IActionResult> GetDeveloperById(int Id)
        {
            var dev = await _repository.GetByIdWithGame(Id);

            return Ok(new DeveloperDTO(dev));
        }

        [Authorize(AuthenticationSchemes = "Bearer")]
        [Authorize(Roles = "Admin")]
        [HttpDelete("{Id}")]
        public async Task<IActionResult> DeleteDeveloper(int Id)
        {
            var dev = await _repository.GetByIdAsync(Id);

            if (dev == null)
            {
                return NotFound("Developer does not exist!");
            }

            _repository.Delete(dev);

            await _repository.SaveAsync();

            return NoContent();
        }

        [Authorize(AuthenticationSchemes = "Bearer")]
        [Authorize(Roles = "Admin")]
        [HttpPost]
        public async Task<IActionResult> CreateDeveloper(CreateDeveloperDTO dto)
        {
            Developer newdev = new Developer();
            newdev.FirstName = dto.FirstName;
            newdev.LastName = dto.LastName;
            newdev.Email = dto.Email;
            newdev.GameId = dto.GameId;
            newdev.Game = dto.Game;

            _repository.Create(newdev);

            await _repository.SaveAsync();

            return Ok(new DeveloperDTO(newdev));

        }

        [Authorize(AuthenticationSchemes = "Bearer")]
        [Authorize(Roles = "Admin")]
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateDeveloper(int id, CreateDeveloperDTO dto)
        {

            var newdev = await _repository.GetByIdWithGame(id);
            if (newdev == null)
            {
                return NotFound("developer dosen't exist with this ID!");
            }

            newdev.FirstName = dto.FirstName;
            newdev.LastName = dto.LastName;
            newdev.Email = dto.Email;
            newdev.GameId = dto.GameId;
            newdev.Game = dto.Game;

            _repository.Update(newdev);

            await _repository.SaveAsync();

            return Ok(new DeveloperDTO(newdev));
        }

    }
}
